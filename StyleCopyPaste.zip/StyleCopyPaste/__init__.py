# __init__.py
def classFactory(iface):
    from .mainPlugin import StyleCopyPastePlugin
    return StyleCopyPastePlugin(iface)
