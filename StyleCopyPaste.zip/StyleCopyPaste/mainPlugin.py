# mainPlugin.py
from qgis.PyQt.QtWidgets import QAction, QToolBar, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtXml import QDomDocument
from qgis.core import QgsProject, QgsMapLayer, QgsVectorLayer

class StyleCopyPastePlugin:
    def __init__(self, iface):
        self.iface = iface
        self.toolbar = None
        self.style_all = None
        self.style_sym = None
        self.style_lbl = None

    def initGui(self):
        self.toolbar = self.iface.addToolBar("StyleCopyPaste")
        self.toolbar.setObjectName("StyleCopyPasteToolbar")

        self.act_copy_all = QAction(QIcon(), "Copy All Style (CA)", self.iface.mainWindow())
        self.act_copy_sym = QAction(QIcon(), "Copy Symbology (CS)", self.iface.mainWindow())
        self.act_copy_lbl = QAction(QIcon(), "Copy Labels (CL)", self.iface.mainWindow())
        self.act_paste_all = QAction(QIcon(), "Paste All Style (PA)", self.iface.mainWindow())
        self.act_paste_sym = QAction(QIcon(), "Paste Symbology (PS)", self.iface.mainWindow())
        self.act_paste_lbl = QAction(QIcon(), "Paste Labels (PL)", self.iface.mainWindow())

        self.act_copy_all.triggered.connect(self.copy_all_style)
        self.act_copy_sym.triggered.connect(self.copy_symbology_style)
        self.act_copy_lbl.triggered.connect(self.copy_label_style)
        self.act_paste_all.triggered.connect(self.paste_all_style)
        self.act_paste_sym.triggered.connect(self.paste_symbology_style)
        self.act_paste_lbl.triggered.connect(self.paste_label_style)

        self.toolbar.addAction(self.act_copy_all)
        self.toolbar.addAction(self.act_copy_sym)
        self.toolbar.addAction(self.act_copy_lbl)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.act_paste_all)
        self.toolbar.addAction(self.act_paste_sym)
        self.toolbar.addAction(self.act_paste_lbl)

    def unload(self):
        if self.toolbar is not None:
            self.iface.mainWindow().removeToolBar(self.toolbar)
            self.toolbar = None

    def copy_all_style(self):
        layer = self.iface.activeLayer()
        if layer and isinstance(layer, QgsVectorLayer):
            doc = QDomDocument("qgis_style")
            layer.exportNamedStyle(doc, QgsMapLayer.AllStyleCategories)
            self.style_all = doc.toString()
            self.iface.messageBar().pushInfo("StyleCopyPaste", "Copied all style categories.")
        else:
            QMessageBox.warning(self.iface.mainWindow(), "StyleCopyPaste",
                                 "Please select a valid vector layer to copy style.")

    def copy_symbology_style(self):
        layer = self.iface.activeLayer()
        if layer and isinstance(layer, QgsVectorLayer):
            doc = QDomDocument("qgis_style")
            layer.exportNamedStyle(doc, QgsMapLayer.Symbology)
            self.style_sym = doc.toString()
            self.iface.messageBar().pushInfo("StyleCopyPaste", "Copied symbology style.")
        else:
            QMessageBox.warning(self.iface.mainWindow(), "StyleCopyPaste",
                                 "Please select a valid vector layer to copy symbology.")

    def copy_label_style(self):
        layer = self.iface.activeLayer()
        if layer and isinstance(layer, QgsVectorLayer):
            doc = QDomDocument("qgis_style")
            layer.exportNamedStyle(doc, QgsMapLayer.Labeling)
            self.style_lbl = doc.toString()
            self.iface.messageBar().pushInfo("StyleCopyPaste", "Copied labeling style.")
        else:
            QMessageBox.warning(self.iface.mainWindow(), "StyleCopyPaste",
                                 "Please select a valid vector layer to copy labels.")

    def paste_all_style(self):
        layer = self.iface.activeLayer()
        if layer and isinstance(layer, QgsVectorLayer) and self.style_all:
            doc = QDomDocument("qgis_style")
            doc.setContent(self.style_all)
            layer.importNamedStyle(doc, QgsMapLayer.AllStyleCategories)
            layer.triggerRepaint()
            self.iface.messageBar().pushSuccess("StyleCopyPaste", "Pasted all style categories.")
        else:
            QMessageBox.warning(self.iface.mainWindow(), "StyleCopyPaste",
                                 "No copied style or invalid target layer for pasting.")

    def paste_symbology_style(self):
        layer = self.iface.activeLayer()
        if layer and isinstance(layer, QgsVectorLayer) and self.style_sym:
            doc = QDomDocument("qgis_style")
            doc.setContent(self.style_sym)
            layer.importNamedStyle(doc, QgsMapLayer.Symbology)
            layer.triggerRepaint()
            self.iface.messageBar().pushSuccess("StyleCopyPaste", "Pasted symbology style.")
        else:
            QMessageBox.warning(self.iface.mainWindow(), "StyleCopyPaste",
                                 "No copied symbology or invalid target layer.")

    def paste_label_style(self):
        layer = self.iface.activeLayer()
        if layer and isinstance(layer, QgsVectorLayer) and self.style_lbl:
            doc = QDomDocument("qgis_style")
            doc.setContent(self.style_lbl)
            layer.importNamedStyle(doc, QgsMapLayer.Labeling)
            layer.triggerRepaint()
            self.iface.messageBar().pushSuccess("StyleCopyPaste", "Pasted labeling style.")
        else:
            QMessageBox.warning(self.iface.mainWindow(), "StyleCopyPaste",
                                 "No copied labels or invalid target layer.")
